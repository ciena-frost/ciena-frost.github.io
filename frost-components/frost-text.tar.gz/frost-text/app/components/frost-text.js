export { default } from 'frost-text/pods/components/frost-text/component';
