/* globals module */
/* jshint node: true */

'use strict';

module.exports = {
	name: 'frost-text',

	included: function(app) {
		this._super.included(app);
	}
};
