export default function() {
  this.passthrough();
}
