/* globals module */
/* jshint node: true */

'use strict';

module.exports = {
	name: 'frost-button',

	included: function(app) {
		this._super.included(app);
	}
};
