export { default } from 'frost-button/pods/components/frost-button/component';
