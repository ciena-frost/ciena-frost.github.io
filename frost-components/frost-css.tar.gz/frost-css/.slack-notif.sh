#!/bin/bash
export SLACK_NOTIFICATION_CHANNELS="#titan #reach"
