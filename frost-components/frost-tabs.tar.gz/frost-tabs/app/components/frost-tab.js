export { default } from 'frost-tabs/pods/components/frost-tab/component';
