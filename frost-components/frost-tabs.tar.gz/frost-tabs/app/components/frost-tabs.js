export { default } from 'frost-tabs/pods/components/frost-tabs/component';
