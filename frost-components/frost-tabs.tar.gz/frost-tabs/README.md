# Frost-Tabs

Tabs based off of <a href='https://www.muicss.com/docs/v1/css-js/tabs'>MUI-CSS</a>. Usage is dead simple. `id`'s of frost-tab must match `id` in supplied argument to `frostTabs`. The `id` of the current element is used to toggle `display: none | block`.

## Usage

See the demo application for usage information.

* `git clone <name of repo>;`
* `npm install && bower install;`

## Installation

* `ember install frost-tabs`
