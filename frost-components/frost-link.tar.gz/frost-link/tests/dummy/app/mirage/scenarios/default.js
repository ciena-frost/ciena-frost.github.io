export default function(server) {
	server.createList('link', 2);
}
