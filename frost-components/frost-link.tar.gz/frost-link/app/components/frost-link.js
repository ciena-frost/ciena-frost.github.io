export { default } from 'frost-link/pods/components/frost-link/component';
