'use strict';

module.exports = function(/* environment, appConfig */) {
	var ENV = {
		podModulePrefix: 'frost-svg/pods'
	};

	return ENV;
};
