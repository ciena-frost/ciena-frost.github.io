export { default } from 'frost-svg/pods/components/frost-svg/component';
