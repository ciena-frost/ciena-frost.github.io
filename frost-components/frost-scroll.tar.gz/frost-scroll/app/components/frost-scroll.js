export { default } from 'frost-scroll/pods/components/frost-scroll/component';
